export const port = 3000;
export const redisURL = 'redis://127.0.0.1:6379';
export const serviceURL = 'http://localhost:9797';
export const jwtSecret = 'totally_real_secret_key';

/**
 * Please rename this file to config.js and fill in the missing values.
 */
