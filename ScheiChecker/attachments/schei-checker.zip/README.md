## To run Schei Checker with Docker-Compose:

```bash
mv .example.env .env
nano .env
bash generate_config_files.sh
docker-compose up
# if everything runs correctly,
docker-compose down && docker-compose up -d
```

- ???
- Profit
